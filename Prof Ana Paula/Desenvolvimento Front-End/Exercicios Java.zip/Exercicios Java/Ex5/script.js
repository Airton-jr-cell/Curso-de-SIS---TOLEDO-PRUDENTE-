function copiarValor() {
      let valor = document.getElementById("campo1").value;
      document.getElementById("campo2").value = valor;
    }